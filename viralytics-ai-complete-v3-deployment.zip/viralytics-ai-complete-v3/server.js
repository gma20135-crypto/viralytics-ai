require("dotenv").config();
const express = require("express");
const session = require("express-session");
const SQLiteStore = require("connect-sqlite3")(session);
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const multer = require("multer");
const crypto = require("node:crypto");
const fs = require("node:fs");
const path = require("node:path");
const { google } = require("googleapis");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const production = process.env.NODE_ENV === "production";
const dataDir = path.join(__dirname, "data");
const uploadsDir = path.join(dataDir, "uploads");
fs.mkdirSync(dataDir, { recursive: true });
fs.mkdirSync(uploadsDir, { recursive: true });

const required = ["SESSION_SECRET", "TOKEN_ENCRYPTION_KEY", "GOOGLE_CLIENT_ID", "GOOGLE_CLIENT_SECRET", "GOOGLE_REDIRECT_URI"];
const encryptionKey = /^[0-9a-fA-F]{64}$/.test(process.env.TOKEN_ENCRYPTION_KEY || "")
  ? Buffer.from(process.env.TOKEN_ENCRYPTION_KEY, "hex") : null;
const googleConfigured = required.every(k => Boolean(process.env[k])) &&
  (process.env.SESSION_SECRET || "").length >= 32 && Boolean(encryptionKey);
const aiConfigured = Boolean(process.env.OPENAI_API_KEY);
if (production && !googleConfigured) {
  console.error("Configuration production incomplète : vérifie SESSION_SECRET, TOKEN_ENCRYPTION_KEY et OAuth Google.");
  process.exit(1);
}
if (production) app.set("trust proxy", 1);

app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"], scriptSrc: ["'self'"], styleSrc: ["'self'"],
      imgSrc: ["'self'", "data:", "https://yt3.ggpht.com", "https://yt3.googleusercontent.com", "https://i.ytimg.com"],
      connectSrc: ["'self'"], objectSrc: ["'none'"], baseUri: ["'self'"],
      frameAncestors: ["'none'"], upgradeInsecureRequests: production ? [] : null
    }
  },
  crossOriginEmbedderPolicy: false
}));
app.use(express.json({ limit: "40kb" }));
app.use(session({
  store: new SQLiteStore({ db: "sessions.sqlite", dir: dataDir, table: "sessions", concurrentDB: true }),
  name: "viralytics.sid",
  secret: process.env.SESSION_SECRET || "local-development-secret-change-this-now",
  resave: false, saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: production, maxAge: 8 * 60 * 60 * 1000 }
}));
app.use(express.static(path.join(__dirname, "public")));

const generalLimiter = rateLimit({ windowMs: 60_000, limit: 90, standardHeaders: "draft-7", legacyHeaders: false });
const aiLimiter = rateLimit({ windowMs: 60_000, limit: 5, standardHeaders: "draft-7", legacyHeaders: false });
const uploadLimiter = rateLimit({ windowMs: 60 * 60_000, limit: 5, standardHeaders: "draft-7", legacyHeaders: false });
app.use("/api", generalLimiter);

function oauthClient() {
  return new google.auth.OAuth2(process.env.GOOGLE_CLIENT_ID, process.env.GOOGLE_CLIENT_SECRET, process.env.GOOGLE_REDIRECT_URI);
}
function encrypt(value) {
  if (!encryptionKey) throw new Error("TOKEN_ENCRYPTION_KEY invalide");
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv("aes-256-gcm", encryptionKey, iv);
  const encrypted = Buffer.concat([cipher.update(JSON.stringify(value), "utf8"), cipher.final()]);
  return { iv: iv.toString("hex"), tag: cipher.getAuthTag().toString("hex"), data: encrypted.toString("hex") };
}
function decrypt(payload) {
  if (!encryptionKey || !payload) throw new Error("Jeton Google indisponible");
  const decipher = crypto.createDecipheriv("aes-256-gcm", encryptionKey, Buffer.from(payload.iv, "hex"));
  decipher.setAuthTag(Buffer.from(payload.tag, "hex"));
  const clear = Buffer.concat([decipher.update(Buffer.from(payload.data, "hex")), decipher.final()]).toString("utf8");
  return JSON.parse(clear);
}
function getAuth(req) {
  const client = oauthClient();
  client.setCredentials(decrypt(req.session.encryptedTokens));
  client.on("tokens", tokens => {
    try {
      const current = decrypt(req.session.encryptedTokens);
      req.session.encryptedTokens = encrypt({ ...current, ...tokens });
    } catch (e) { console.error("Token refresh storage error:", e.message); }
  });
  return client;
}
function connected(req, res, next) {
  if (!req.session.encryptedTokens) return res.status(401).json({ error: "not_connected" });
  try { decrypt(req.session.encryptedTokens); next(); }
  catch { req.session.destroy(() => {}); res.status(401).json({ error: "session_expired" }); }
}
function csrf(req, res, next) {
  const origin = req.get("origin");
  if (origin) {
    try {
      if (new URL(origin).host !== req.get("host")) return res.status(403).json({ error: "origin_rejected" });
    } catch { return res.status(403).json({ error: "origin_rejected" }); }
  }
  const supplied = req.get("x-csrf-token") || "";
  const expected = req.session.csrfToken || "";
  const a = Buffer.from(supplied), b = Buffer.from(expected);
  if (!a.length || a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
    return res.status(403).json({ error: "csrf_rejected" });
  }
  next();
}
const upload = multer({
  dest: uploadsDir,
  limits: { fileSize: 512 * 1024 * 1024, files: 1 },
  fileFilter: (req, file, cb) => {
    const allowed = new Set(["video/mp4", "video/quicktime", "video/webm", "video/mpeg"]);
    cb(allowed.has(file.mimetype) ? null : new Error("Format vidéo non pris en charge (MP4, MOV, WebM ou MPEG)."), allowed.has(file.mimetype));
  }
});
const snapshotsPath = path.join(dataDir, "radar-snapshots.json");
async function readSnapshots() {
  try { return JSON.parse(await fs.promises.readFile(snapshotsPath, "utf8")); }
  catch { return {}; }
}
async function writeSnapshots(data) {
  const tmp = snapshotsPath + ".tmp";
  await fs.promises.writeFile(tmp, JSON.stringify(data), { mode: 0o600 });
  await fs.promises.rename(tmp, snapshotsPath);
}
const dateOnly = d => d.toISOString().slice(0, 10);
const safeError = e => e?.response?.data?.error?.message || e?.message || "Erreur inconnue";

app.get("/api/status", (req, res) => {
  if (!req.session.csrfToken) req.session.csrfToken = crypto.randomBytes(32).toString("hex");
  res.set("Cache-Control", "no-store");
  res.json({
    csrfToken: req.session.csrfToken,
    googleConfigured,
    connected: Boolean(req.session.encryptedTokens),
    aiConfigured,
    modules: { radar: true, historicalAcceleration: true, aiStudio: aiConfigured, upload: true, scheduling: true }
  });
});

app.get("/auth/google", (req, res) => {
  if (!googleConfigured) return res.status(503).send("Configuration Google incomplète. Consulte le README.");
  const state = crypto.randomBytes(32).toString("hex");
  req.session.oauthState = state;
  const client = oauthClient();
  const url = client.generateAuthUrl({
    access_type: "offline", prompt: "consent", state,
    scope: [
      "https://www.googleapis.com/auth/youtube.readonly",
      "https://www.googleapis.com/auth/yt-analytics.readonly",
      "https://www.googleapis.com/auth/youtube.upload"
    ]
  });
  req.session.save(err => err ? res.status(500).send("Impossible de démarrer la connexion.") : res.redirect(url));
});
app.get("/oauth2callback", async (req, res) => {
  try {
    const expected = String(req.session.oauthState || "");
    const received = String(req.query.state || "");
    delete req.session.oauthState;
    const a = Buffer.from(expected), b = Buffer.from(received);
    if (!expected || !received || a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
      return res.status(400).send("Vérification de sécurité échouée. Recommence la connexion.");
    }
    if (req.query.error) return res.redirect("/?connection=cancelled");
    if (!req.query.code) return res.status(400).send("Code Google manquant.");
    const { tokens } = await oauthClient().getToken(req.query.code);
    req.session.encryptedTokens = encrypt(tokens);
    req.session.save(err => err ? res.status(500).send("Impossible d'enregistrer la session.") : res.redirect("/?connected=1"));
  } catch (e) {
    console.error("OAuth callback:", e.message);
    res.status(500).send("Connexion Google impossible. Réessaie.");
  }
});

app.get("/api/youtube", connected, async (req, res) => {
  res.set("Cache-Control", "no-store");
  try {
    const auth = getAuth(req), youtube = google.youtube({ version: "v3", auth });
    const response = await youtube.channels.list({ part: ["snippet", "statistics", "contentDetails"], mine: true });
    const channel = response.data.items?.[0];
    if (!channel) return res.json({ channel: null, videos: [], analytics: null });
    const [playlist, analytics] = await Promise.all([
      youtube.playlistItems.list({ part: ["snippet", "contentDetails"], playlistId: channel.contentDetails.relatedPlaylists.uploads, maxResults: 10 }),
      (async () => {
        try {
          const api = google.youtubeAnalytics({ version: "v2", auth });
          const end = new Date(); end.setDate(end.getDate() - 2);
          const start = new Date(end); start.setDate(start.getDate() - 27);
          const report = await api.reports.query({
            ids: "channel==MINE", startDate: dateOnly(start), endDate: dateOnly(end),
            metrics: "views,estimatedMinutesWatched,subscribersGained",
            dimensions: "day", sort: "day"
          });
          const rows = report.data.rows || [];
          return {
            available: true, startDate: dateOnly(start), endDate: dateOnly(end),
            totals: rows.reduce((a, r) => ({
              views: a.views + Number(r[1] || 0),
              watchMinutes: a.watchMinutes + Number(r[2] || 0),
              subscribersGained: a.subscribersGained + Number(r[3] || 0)
            }), { views: 0, watchMinutes: 0, subscribersGained: 0 }),
            daily: rows.map(r => ({ date: r[0], views: Number(r[1] || 0) }))
          };
        } catch (e) { return { available: false, reason: "analytics_unavailable" }; }
      })()
    ]);
    res.json({
      channel: {
        id: channel.id, title: channel.snippet.title, description: channel.snippet.description,
        thumbnail: channel.snippet.thumbnails?.high?.url || channel.snippet.thumbnails?.default?.url || null,
        subscribers: channel.statistics.hiddenSubscriberCount ? null : Number(channel.statistics.subscriberCount || 0),
        hiddenSubscriberCount: Boolean(channel.statistics.hiddenSubscriberCount),
        views: Number(channel.statistics.viewCount || 0), videoCount: Number(channel.statistics.videoCount || 0)
      },
      videos: (playlist.data.items || []).map(x => ({
        title: x.snippet.title, publishedAt: x.snippet.publishedAt,
        thumbnail: x.snippet.thumbnails?.medium?.url || x.snippet.thumbnails?.default?.url || null,
        videoId: x.contentDetails.videoId
      })),
      analytics
    });
  } catch (e) { console.error("YouTube:", safeError(e)); res.status(502).json({ error: "youtube_api_error", message: safeError(e) }); }
});

app.get("/api/radar/search", connected, async (req, res) => {
  const q = String(req.query.q || "").trim().slice(0, 100);
  const region = String(req.query.region || "FR").toUpperCase();
  const allowedRegions = new Set(["FR","US","GB","CA","BE","CH","DE","ES","IT","JP","BR","AU","IN"]);
  if (q.length < 2) return res.status(400).json({ error: "query_too_short" });
  if (!allowedRegions.has(region)) return res.status(400).json({ error: "invalid_region" });
  try {
    const auth = getAuth(req), youtube = google.youtube({ version: "v3", auth });
    const search = await youtube.search.list({
      part: ["snippet"], q, type: ["video"], order: "viewCount",
      regionCode: region, maxResults: 20, publishedAfter: new Date(Date.now() - 30*86400000).toISOString()
    });
    const ids = (search.data.items || []).map(x => x.id.videoId).filter(Boolean);
    if (!ids.length) return res.json({ region, query: q, items: [], note: "Aucun résultat." });
    const details = await youtube.videos.list({ part: ["snippet","statistics","contentDetails"], id: ids });
    const today = dateOnly(new Date()), snapshots = await readSnapshots();
    const items = (details.data.items || []).map(v => {
      const views = Number(v.statistics.viewCount || 0);
      const previous = snapshots[v.id] || [];
      const old = previous.filter(x => x.date < today).sort((a,b)=>a.date.localeCompare(b.date)).at(-1);
      const current = { date: today, views };
      const next = [...previous.filter(x => x.date !== today), current].slice(-60);
      snapshots[v.id] = next;
      const delta = old ? views - old.views : null;
      const days = old ? Math.max(1, (new Date(today) - new Date(old.date)) / 86400000) : null;
      return {
        id: v.id, title: v.snippet.title, channelTitle: v.snippet.channelTitle,
        channelId: v.snippet.channelId, thumbnail: v.snippet.thumbnails?.medium?.url || null,
        publishedAt: v.snippet.publishedAt, views,
        likes: Number(v.statistics.likeCount || 0), comments: Number(v.statistics.commentCount || 0),
        growthViews: delta, averageViewsPerDay: delta === null ? null : Math.round(delta / days),
        growthPercent: old && old.views > 0 ? Math.round((delta / old.views) * 1000) / 10 : null,
        observations: next.length, youtubeUrl: `https://www.youtube.com/watch?v=${v.id}`
      };
    });
    await writeSnapshots(snapshots);
    items.sort((a,b) => (b.averageViewsPerDay ?? -1) - (a.averageViewsPerDay ?? -1));
    res.json({
      region, query: q, items,
      note: "La première observation sert de point de départ. La progression devient mesurable après de nouvelles observations un autre jour."
    });
  } catch (e) { console.error("Radar:", safeError(e)); res.status(502).json({ error: "radar_api_error", message: safeError(e) }); }
});

app.post("/api/ai/generate", aiLimiter, csrf, async (req, res) => {
  if (!process.env.OPENAI_API_KEY) return res.status(503).json({ error: "ai_not_configured" });
  const { topic, format = "Short", audience = "grand public", tone = "dynamique" } = req.body || {};
  if (typeof topic !== "string" || topic.trim().length < 3 || topic.length > 500) {
    return res.status(400).json({ error: "invalid_topic" });
  }
  const prompt = `Tu es un assistant de production YouTube. Prépare un projet original en français.
Sujet : ${topic.trim()}
Format : ${String(format).slice(0,30)}
Public visé : ${String(audience).slice(0,100)}
Ton : ${String(tone).slice(0,60)}
Retourne uniquement un objet JSON avec les clés: title, hook, script, scenes (tableau d'objets {visual, narration, onScreenText}), description, tags (tableau), thumbnailConcept, subtitles.
Le script doit être original, factuel, sans inventer de chiffres ou de sources. Signale dans le script les éléments à vérifier. N'imite pas le style exact d'un créateur existant. Ne reproduis pas de paroles ou de longs extraits protégés.`;
  try {
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: { "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || "gpt-4.1-mini",
        messages: [{ role: "user", content: prompt }],
        response_format: { type: "json_object" },
        temperature: 0.7
      })
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error?.message || `Erreur IA ${response.status}`);
    const content = data.choices?.[0]?.message?.content;
    if (!content) throw new Error("Réponse IA vide");
    res.json({ project: JSON.parse(content), model: process.env.OPENAI_MODEL || "gpt-4.1-mini" });
  } catch (e) {
    console.error("AI generation:", e.message);
    res.status(502).json({ error: "ai_generation_failed", message: "La génération IA a échoué. Vérifie la configuration et réessaie." });
  }
});

app.post("/api/youtube/upload", connected, uploadLimiter, csrf, upload.single("video"), async (req, res) => {
  const file = req.file;
  try {
    if (!file) return res.status(400).json({ error: "video_required" });
    if (req.body.confirm !== "yes") return res.status(400).json({ error: "explicit_confirmation_required" });
    const title = String(req.body.title || "").trim().slice(0, 100);
    const description = String(req.body.description || "").slice(0, 5000);
    const privacy = String(req.body.privacy || "private");
    const allowed = new Set(["private", "unlisted", "public"]);
    if (!title) return res.status(400).json({ error: "title_required" });
    if (!allowed.has(privacy)) return res.status(400).json({ error: "invalid_privacy" });
    const body = { snippet: { title, description }, status: { privacyStatus: privacy, selfDeclaredMadeForKids: false } };
    if (req.body.publishAt) {
      const when = new Date(req.body.publishAt);
      if (Number.isNaN(when.getTime()) || when.getTime() < Date.now() + 10*60*1000) {
        return res.status(400).json({ error: "invalid_schedule_time" });
      }
      if (privacy !== "private") return res.status(400).json({ error: "scheduled_video_must_be_private" });
      body.status.publishAt = when.toISOString();
    }
    const youtube = google.youtube({ version: "v3", auth: getAuth(req) });
    const result = await youtube.videos.insert({
      part: ["snippet", "status"], requestBody: body,
      media: { body: fs.createReadStream(file.path) }
    });
    res.json({
      ok: true, videoId: result.data.id,
      url: `https://www.youtube.com/watch?v=${result.data.id}`,
      status: result.data.status?.privacyStatus,
      publishAt: result.data.status?.publishAt || null
    });
  } catch (e) {
    console.error("Upload:", safeError(e));
    res.status(502).json({ error: "upload_failed", message: "L'envoi a échoué. Vérifie le format, la connexion et les limites YouTube." });
  } finally {
    if (file?.path) fs.promises.unlink(file.path).catch(() => {});
  }
});

app.post("/auth/logout", csrf, (req, res) => {
  req.session.destroy(err => {
    if (err) return res.status(500).json({ error: "logout_failed" });
    res.clearCookie("viralytics.sid", { httpOnly: true, sameSite: "lax", secure: production });
    res.json({ ok: true });
  });
});

app.use((err, req, res, next) => {
  if (err instanceof multer.MulterError) return res.status(400).json({ error: "upload_limit_or_file_error", message: err.message });
  if (err) return res.status(400).json({ error: "request_error", message: err.message || "Requête invalide." });
  next();
});
app.get("*", (req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));
app.listen(PORT, () => console.log(`VIRALYTICS AI V3 prêt sur le port ${PORT}`));
