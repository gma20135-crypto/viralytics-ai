# VIRALYTICS AI V3 — radar, IA, studio et publication

## Modules intégrés au code
- Radar : recherche de vidéos YouTube par sujet et région via YouTube Data API.
- Suivi : sauvegarde des vues observées par date ; calcul d'écart et de rythme moyen quand une observation antérieure existe.
- Chaîne : statistiques de la chaîne connectée, dernières vidéos et tentative Analytics 28 jours.
- IA : génération de projet (titre, accroche, script, scènes, description, tags, concept miniature et texte de sous-titres) via API OpenAI, si une clé est configurée.
- Studio : brouillon local, script, scènes, description, sous-titres et export texte.
- Publication : upload d'un fichier vidéo choisi par l'utilisateur, avec titre, description, visibilité et programmation. Confirmation explicite requise.
- Protection : sessions persistantes SQLite, chiffrement AES-256-GCM des jetons OAuth dans la session, cookies HttpOnly/SameSite, jeton CSRF pour les actions POST, contrôle Origin, limite de débit, limite de taille d'upload, CSP.

## Ce qui reste limité
- Le radar utilise la recherche YouTube des vidéos publiées sur les 30 derniers jours et ordonnées par vues. La première observation n'est pas une mesure de croissance : le suivi nécessite de refaire des recherches à plusieurs dates. La Data API a des quotas et ne donne pas l'historique privé des concurrents.
- Le radar n'est pas encore une veille automatique quotidienne en arrière-plan. Il faut ajouter un planificateur de tâches hébergé et une stratégie de quotas.
- La génération IA nécessite une clé API et un budget configuré par l'administrateur. Les résultats doivent être vérifiés.
- Le studio prépare les éléments de production mais ne génère pas encore de fichier vidéo monté, de piste audio ou de miniature graphique.
- La publication nécessite l'autorisation YouTube upload. Les règles, limites, vérifications et restrictions de compte YouTube s'appliquent.
- La base ne crée pas d'APK et n'est pas encore déployée.
- Les idées et projets du studio sont enregistrés dans le navigateur local, pas synchronisés entre appareils.

## Installation locale
1. Node.js 20 ou supérieur.
2. Copie `.env.example` vers `.env`.
3. Installe les dépendances : `npm install`.
4. Renseigne les clés et URL de redirection.
5. Lance : `npm start`.

## Google Cloud / YouTube
Dans Google Cloud Console :
1. Crée un projet et active YouTube Data API v3 et YouTube Analytics API.
2. Configure l'écran de consentement OAuth.
3. Crée un client OAuth de type application Web.
4. Déclare exactement l'URL `https://TON-DOMAINE/oauth2callback`.
5. Dans `.env`, configure `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET`, `GOOGLE_REDIRECT_URI`, `BASE_URL`, `SESSION_SECRET` et `TOKEN_ENCRYPTION_KEY`.
6. Les scopes demandés sont YouTube readonly, Analytics readonly et upload.

Génération de secrets :
- `SESSION_SECRET` : au moins 32 caractères aléatoires.
- `TOKEN_ENCRYPTION_KEY` : exactement 64 caractères hexadécimaux (32 octets). Exemple de génération locale avec Node : `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"`.

## IA
Ajoute `OPENAI_API_KEY` dans l'environnement serveur et éventuellement `OPENAI_MODEL`. Ne mets jamais la clé dans le code du navigateur ni dans un fichier public. L'administrateur doit vérifier les coûts et les conditions d'utilisation du fournisseur.

## Publication
Le téléversement est volontairement déclenché par l'utilisateur et exige une case de confirmation. Les vidéos programmées sont envoyées en privé avec `publishAt`. Les règles de programmation et l'éligibilité dépendent de YouTube. Commence par tester en privé.

## Déploiement et sécurité avant ouverture publique
- Utiliser HTTPS et un domaine contrôlé.
- Protéger le fichier `.env` et les sauvegardes du dossier `data/`.
- Prévoir sauvegarde et restauration SQLite.
- Configurer la politique de confidentialité et les exigences de vérification OAuth/YouTube.
- Ajouter une surveillance des erreurs et une procédure de révocation des accès.
- Ne jamais envoyer de données personnelles sensibles dans les prompts.
- Vérifier les droits sur les vidéos, musiques, images et éléments utilisés.
- Ne partage jamais les mots de passe, clés API ou jetons dans une conversation.

## Installer sur Samsung
Après déploiement HTTPS, ouvrir le domaine dans Chrome Android → menu ⋮ → « Installer l'application » ou « Ajouter à l'écran d'accueil ».
\n\n## Déploiement hébergé\nConsulte `DEPLOYMENT.md` et `render.yaml` pour une configuration de déploiement sur Render avec stockage persistant. Le déploiement et les autorisations Google doivent être effectués dans les comptes du propriétaire.\n