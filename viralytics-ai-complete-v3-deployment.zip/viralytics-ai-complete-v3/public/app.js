let csrfToken = "";
const $ = id => document.getElementById(id);
const fmt = n => Number(n || 0).toLocaleString("fr-FR");
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const safeUrl = raw => { try { const u = new URL(raw); return ["https:","http:"].includes(u.protocol) ? u.href : ""; } catch { return ""; } };
async function api(url, options={}) {
  const headers = new Headers(options.headers || {});
  if (options.method && options.method !== "GET") headers.set("X-CSRF-Token", csrfToken);
  return fetch(url, { ...options, headers, credentials:"same-origin" });
}
async function init() {
  const status = await fetch("/api/status").then(r=>r.json()).catch(()=>null);
  if (!status) { $("connectionStatus").textContent="Serveur inaccessible"; return; }
  csrfToken = status.csrfToken;
  $("connectionStatus").textContent = status.connected ? "YouTube connecté" : "YouTube non connecté";
  if (!status.googleConfigured) {
    $("connect").classList.add("disabled");
    $("connect").addEventListener("click", e=>{e.preventDefault();$("configNote").textContent="OAuth Google doit être configuré sur le serveur.";});
  } else $("configNote").textContent="La connexion s'effectue sur le site officiel Google.";
  if (!status.aiConfigured) $("aiNote").textContent="IA non activée : une clé API doit être ajoutée dans la configuration serveur.";
  if (status.connected) await loadChannel();
}
async function loadChannel() {
  try {
    const r=await fetch("/api/youtube"); if(!r.ok) throw new Error("Impossible de charger la chaîne.");
    const d=await r.json(); if(!d.channel) return;
    $("channelSection").classList.remove("hidden");
    $("channelName").textContent=d.channel.title;
    $("channelDesc").textContent=d.channel.description || "";
    if(d.channel.thumbnail) $("channelImg").src=safeUrl(d.channel.thumbnail);
    $("subs").textContent=d.channel.hiddenSubscriberCount?"Masqué":fmt(d.channel.subscribers);
    $("views").textContent=fmt(d.channel.views); $("count").textContent=fmt(d.channel.videoCount);
    $("views28").textContent=d.analytics?.available?fmt(d.analytics.totals.views):"Indisponible";
    if(d.analytics?.available) {
      const vals=d.analytics.daily.map(x=>x.views), max=Math.max(1,...vals);
      const pts=vals.map((v,i)=>`${i/Math.max(1,vals.length-1)*300},${78-v/max*66}`).join(" ");
      $("chart").innerHTML=`<svg viewBox="0 0 300 90" role="img" aria-label="Courbe quotidienne des vues"><polyline points="${pts}" fill="none" stroke="#54d7e8" stroke-width="3" stroke-linecap="round"/></svg>`;
    } else $("chart").textContent="Analytics indisponible pour cette chaîne ou cette période.";
    const host=$("videos"); host.replaceChildren();
    (d.videos||[]).forEach(v=>{
      const item=document.createElement("div"); item.className="card row";
      const img=document.createElement("img");img.className="video";img.alt="";img.src=safeUrl(v.thumbnail);
      const txt=document.createElement("div");txt.className="grow";
      const b=document.createElement("b");b.textContent=v.title;
      const sm=document.createElement("small");sm.textContent=new Date(v.publishedAt).toLocaleDateString("fr-FR");
      txt.append(b,sm);item.append(img,txt);host.append(item);
    });
  } catch(e) { $("configNote").textContent=e.message; }
}
$("searchRadar").addEventListener("click", async()=>{
  const q=$("radarQuery").value.trim(); if(q.length<2){$("radarNote").textContent="Saisis au moins deux caractères.";return;}
  $("searchRadar").disabled=true;$("radarNote").textContent="Recherche en cours…";
  try {
    const r=await fetch(`/api/radar/search?q=${encodeURIComponent(q)}&region=${encodeURIComponent($("radarRegion").value)}`);
    const d=await r.json(); if(!r.ok) throw new Error(d.message || (d.error==="not_connected"?"Connecte d'abord ta chaîne YouTube.":"La recherche a échoué."));
    $("radarNote").textContent=d.note;
    const host=$("radarResults");host.replaceChildren();
    d.items.forEach(v=>{
      const card=document.createElement("div");card.className="card radar-item";
      const img=document.createElement("img");img.alt="";img.src=safeUrl(v.thumbnail);
      const body=document.createElement("div");body.className="grow";
      const a=document.createElement("a");a.href=safeUrl(v.youtubeUrl);a.target="_blank";a.rel="noopener noreferrer";a.textContent=v.title;
      const channel=document.createElement("div");channel.className="notice";channel.textContent=v.channelTitle;
      const metrics=document.createElement("div");metrics.className="metric";
      metrics.textContent=v.growthViews===null?`${fmt(v.views)} vues · première observation`:`${fmt(v.views)} vues · +${fmt(v.growthViews)} depuis la dernière observation · ${v.growthPercent}%`;
      body.append(a,channel,metrics);card.append(img,body);host.append(card);
    });
  } catch(e){$("radarNote").textContent=e.message;}
  finally{$("searchRadar").disabled=false;}
});
$("generateAI").addEventListener("click", async()=>{
  const topic=$("aiTopic").value.trim(); if(!topic){$("aiNote").textContent="Indique le sujet de ta vidéo.";return;}
  $("generateAI").disabled=true;$("aiNote").textContent="L'IA prépare ton projet…";
  try {
    const r=await api("/api/ai/generate",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({topic,format:$("aiFormat").value,audience:$("aiAudience").value,tone:$("aiTone").value})});
    const d=await r.json();if(!r.ok)throw new Error(d.error==="ai_not_configured"?"La clé IA n'est pas configurée sur le serveur.":"La génération IA a échoué.");
    const p=d.project;
    $("studioTitle").value=p.title||"";$("studioScript").value=p.script||"";
    $("studioDescription").value=p.description||"";$("studioSubs").value=p.subtitles||"";
    $("studioScenes").value=(p.scenes||[]).map((s,i)=>`SCÈNE ${i+1}\nVisuel : ${s.visual||""}\nVoix off : ${s.narration||""}\nTexte écran : ${s.onScreenText||""}`).join("\n\n");
    const box=$("aiResult");box.classList.remove("hidden");box.replaceChildren();
    const title=document.createElement("h3");title.textContent=p.title||"Projet généré";
    const hook=document.createElement("p");hook.textContent="Accroche : "+(p.hook||"");
    const thumb=document.createElement("p");thumb.textContent="Idée de miniature : "+(p.thumbnailConcept||"");
    box.append(title,hook,thumb);$("studioSection").scrollIntoView({behavior:"smooth"});
    $("aiNote").textContent="Projet généré. Relis et vérifie les informations avant utilisation.";
  } catch(e){$("aiNote").textContent=e.message;}
  finally{$("generateAI").disabled=false;}
});
const projectFields=["studioTitle","studioFormat","studioScript","studioScenes","studioDescription","studioSubs"];
function projectText(){
  return `VIRALYTICS AI — PLAN DE PRODUCTION\nTitre : ${$("studioTitle").value}\nFormat : ${$("studioFormat").value}\n\nSCRIPT / VOIX OFF\n${$("studioScript").value}\n\nSCÈNES / VISUELS\n${$("studioScenes").value}\n\nDESCRIPTION\n${$("studioDescription").value}\n\nSOUS-TITRES\n${$("studioSubs").value}\n`;
}
$("saveStudio").addEventListener("click",()=>{
  const p={};projectFields.forEach(k=>p[k]=$(k).value);localStorage.setItem("viralytics.v3.project",JSON.stringify(p));$("studioNote").textContent="Brouillon enregistré sur cet appareil.";
});
$("exportStudio").addEventListener("click",()=>{
  const blob=new Blob([projectText()],{type:"text/plain;charset=utf-8"});const url=URL.createObjectURL(blob);
  const a=document.createElement("a");a.href=url;a.download="viralytics-plan-video.txt";a.click();URL.revokeObjectURL(url);
});
try {const p=JSON.parse(localStorage.getItem("viralytics.v3.project")||"null");if(p)projectFields.forEach(k=>{if(p[k]!==undefined)$(k).value=p[k];});}catch{}
$("uploadVideo").addEventListener("click",async()=>{
  const file=$("videoFile").files[0];
  if(!file){$("publishNote").textContent="Choisis d'abord ton fichier vidéo.";return;}
  if(!$("publishConfirm").checked){$("publishNote").textContent="Coche la confirmation après avoir vérifié tous les détails.";return;}
  if(!$("publishTitle").value.trim()){ $("publishNote").textContent="Ajoute un titre.";return;}
  const form=new FormData();form.append("video",file);form.append("title",$("publishTitle").value);
  form.append("description",$("publishDescription").value);form.append("privacy",$("publishPrivacy").value);
  form.append("confirm","yes");if($("publishAt").value)form.append("publishAt",new Date($("publishAt").value).toISOString());
  $("uploadVideo").disabled=true;$("publishNote").textContent="Envoi en cours. Garde cette page ouverte…";
  try{
    const r=await api("/api/youtube/upload",{method:"POST",body:form});const d=await r.json();
    if(!r.ok)throw new Error(d.message||d.error||"Envoi impossible.");
    $("publishResult").innerHTML=`<p class="metric">Vidéo envoyée avec succès.</p><a target="_blank" rel="noopener noreferrer" href="${esc(d.url)}">Ouvrir la vidéo sur YouTube</a>`;
    $("publishNote").textContent=d.publishAt?`Programmée pour ${new Date(d.publishAt).toLocaleString("fr-FR")}.`:`Visibilité : ${d.status}.`;
  }catch(e){$("publishNote").textContent=e.message;}
  finally{$("uploadVideo").disabled=false;}
});
$("logout").addEventListener("click",async()=>{await api("/auth/logout",{method:"POST"});location.reload();});
init();
if("serviceWorker" in navigator) addEventListener("load",()=>navigator.serviceWorker.register("/sw.js"));
