# Déploiement guidé — VIRALYTICS AI V3

Ce projet est un serveur Node.js avec SQLite et stockage local. Cette configuration cible Render avec un disque persistant. Elle prépare le déploiement, mais ne crée pas le compte Render, le projet Google Cloud, les clés API ni le consentement OAuth à ta place.

## 1. Avant de commencer

- Utiliser un compte d'hébergement avec l'aide d'un parent/tuteur si nécessaire.
- Ne jamais publier le fichier `.env`, les clés ou les jetons.
- Ne pas partager les secrets dans un chat.
- Prévoir un domaine HTTPS ou utiliser le domaine HTTPS fourni par l'hébergeur.
- Vérifier les conditions d'âge et les règles des services tiers.

## 2. Déployer sur Render

1. Déposer le dossier du projet dans un dépôt Git privé.
2. Ouvrir Render et créer un nouveau **Blueprint** à partir de ce dépôt.
3. Render détectera `render.yaml` et préparera le service et son disque persistant.
4. Après création, ouvrir les paramètres du service et relever son URL HTTPS, par exemple `https://nom-du-service.onrender.com`.
5. Renseigner `BASE_URL` avec cette URL exacte.
6. Générer `TOKEN_ENCRYPTION_KEY` localement avec Node.js :
   `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"`
   La valeur doit contenir exactement 64 caractères hexadécimaux.
7. Garder `SESSION_SECRET` généré par Render (au moins 32 caractères).

## 3. Configurer Google / YouTube

Dans Google Cloud Console, avec l'aide d'un adulte responsable si nécessaire :

1. Créer un projet Google Cloud.
2. Activer **YouTube Data API v3** et **YouTube Analytics API**.
3. Configurer l'écran de consentement OAuth et les utilisateurs de test requis.
4. Créer un identifiant OAuth de type **Application Web**.
5. Ajouter comme URI de redirection autorisée l'URL exacte :
   `https://NOM-DU-SERVICE.onrender.com/oauth2callback`
6. Reporter les valeurs dans Render :
   - `GOOGLE_CLIENT_ID`
   - `GOOGLE_CLIENT_SECRET`
   - `GOOGLE_REDIRECT_URI` (doit correspondre exactement à l'URL ci-dessus)
7. Enregistrer puis redéployer.

Les autorisations demandées permettent de lire les informations YouTube et de téléverser une vidéo. Les statistiques privées ne sont accessibles qu'après consentement du propriétaire du compte. L'accès peut être soumis à la vérification Google et aux restrictions du compte.

## 4. Activer l'IA

Ajouter `OPENAI_API_KEY` dans les variables secrètes du service Render. Ne jamais la mettre dans `public/`, dans le navigateur, dans un dépôt Git ou dans une capture d'écran. Vérifier les coûts et les limites du compte API avant activation.

## 5. Test de mise en service

- Ouvrir le site en HTTPS.
- Vérifier l'écran d'accueil.
- Tester la connexion Google et l'accès aux statistiques.
- Lancer une recherche radar avec un sujet simple.
- Tester la génération IA.
- Tester un téléversement en visibilité **privée** uniquement.
- Vérifier la persistance de la session et des données après redémarrage.
- Ne passer à une publication publique qu'après vérification explicite du contenu et des droits.

## 6. Installation sur Samsung

Une fois le site déployé en HTTPS :
1. Ouvrir l'adresse dans Chrome sur le Samsung.
2. Menu ⋮.
3. Choisir **Installer l'application** ou **Ajouter à l'écran d'accueil** selon la version de Chrome.

Cela installe la PWA ; ce n'est pas un APK natif.

## Limites qui restent à traiter

- Le radar n'est pas encore une veille automatique quotidienne.
- La génération IA produit des éléments éditoriaux, pas un montage vidéo final avec voix et miniature exportées.
- Les brouillons du studio sont stockés localement sur l'appareil.
- Il faut encore une politique de confidentialité, des sauvegardes/restaurations testées, un contrôle de coûts et un audit de sécurité avant ouverture publique.
- Les quotas et l'éligibilité YouTube peuvent limiter l'utilisation de l'API.
